public class Main {
    public static void main(String[] args) {
        // Check if exactly two arguments are passed
        if (args.length != 2) {
            System.out.println("Please pass exactly two arguments.");
            return;
        }

        // Retrieve the command line arguments
        String companyName = args[0];
        String cityName = args[1];

        // Generate the required output
        String output = companyName + " Technologies " + cityName;

        // Print the output
        System.out.println(output);
    }
}
