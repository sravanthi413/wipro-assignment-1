public class Sample {
    public static void main(String[] args) {
        // Check if exactly two arguments are passed
        if (args.length != 2) {
            System.out.println("Please pass exactly two arguments.");
            return;
        }

        try {
            // Retrieve the command line arguments and convert them to integers
            int num1 = Integer.parseInt(args[0]);
            int num2 = Integer.parseInt(args[1]);

            // Calculate the sum of the two numbers
            int sum = num1 + num2;

            // Generate the output message
            String outputMessage = "The sum of " + num1 + " and " + num2 + " is " + sum;

            // Print the output message
            System.out.println(outputMessage);
        } catch (NumberFormatException e) {
            // Handle the case where the arguments are not valid integers
            System.out.println("Please enter valid integers.");
        }
    }
}
