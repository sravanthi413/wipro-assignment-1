
public class Sample {
    public static void main(String[] args) {
        // Check if exactly one argument is passed
        if (args.length != 1) {
            System.out.println("Please pass exactly one argument.");
            return;
        }

        // Retrieve the command line argument
        String name = args[0];

        // Generate the welcome message
        String welcomeMessage = "Welcome " + name;

        // Print the welcome message
        System.out.println(welcomeMessage);
    }
}
